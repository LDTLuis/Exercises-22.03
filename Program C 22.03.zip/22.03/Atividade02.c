#include <stdio.h>

int main (void) {

    int i = 0;

    do {
        printf("Palavra\n");
        i++;

    } while (i < 20);

    return 0;
}
