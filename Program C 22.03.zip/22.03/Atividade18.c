#include <stdio.h>

int main (void) {

    int i = 1;

    do {
        printf("%d\n", i);
        i++;
    } while (i <20);

    return 0;
}
