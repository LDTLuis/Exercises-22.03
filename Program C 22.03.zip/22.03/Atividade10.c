#include <stdio.h>

int main (void) {

    int i;
    char word[15] = "Lu�s";

    do {
        printf("Voc� digitou: %s\n", word);
    } while (i < 20);

    return 0;
}
