#include <stdio.h>

int main (void) {

    int i = 0;

    while (i < 20) {
        printf("Palavra\n");
        i++;
    }

    return 0;
}
