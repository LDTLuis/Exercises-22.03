#include <stdio.h>

int main (void) {

    int i;
    char word[15] = "Lu�s";

    while (i < 20) {
        printf("Voc� digitou: %s\n", word);
    }

    return 0;
}
